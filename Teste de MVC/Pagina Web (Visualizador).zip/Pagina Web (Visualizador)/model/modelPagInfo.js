import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";
import { getFirestore, collection, doc, getDoc, query, where, getDocs, updateDoc, deleteDoc } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";
import 'https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns';

const firebaseConfig = {
    apiKey: "AIzaSyA7M2fuyG3owV9dWM706YMJnqQ9Jbe6DSo",
    authDomain: "teste-7fa12.firebaseapp.com",
    databaseURL: "https://teste-7fa12-default-rtdb.firebaseio.com",
    projectId: "teste-7fa12",
    storageBucket: "teste-7fa12.appspot.com",
    messagingSenderId: "340432857585",
    appId: "1:340432857585:web:58169c01b8eaa901dafc50",
    measurementId: "G-ZB0X9DV029",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export async function fetchDevice(estacao) {
    const dispositivoSnap = await getDoc(doc(db, "dispositivos", estacao));
    if (dispositivoSnap.exists()) {
        return { id: dispositivoSnap.id, ...dispositivoSnap.data() };
    } else {
        throw new Error('Nenhum dispositivo encontrado.');
    }
}

export async function updateDevice(estacao, updateFields) {
    console.log("Dados Salvos com Sucesso!!");
    alert("Dados Salvos com Sucesso!!");
    await updateDoc(doc(db, "dispositivos", estacao), updateFields);
}

export async function deleteDevice(estacao) {
    await deleteDoc(doc(db, "dispositivos", estacao));
    window.location.href="listEstacaoTeste.html"
}

export async function fetchMeasurements(estacao) {
    const medicoesEstacao = query(collection(db, 'medicoes'), where('dispositivo_id', '==', estacao));
    const querySnapshot = await getDocs(medicoesEstacao);
    return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

export async function fetchAllSensors() {
    const sensoresRef = collection(db, "sensores");
    const querySnapshot = await getDocs(sensoresRef);

    const listaSensores = [];
    querySnapshot.forEach((doc) => {
        listaSensores.push(doc.id);
    });

    return listaSensores;
}

export async function fetchChartData(estacao) {
    const medicoesEstacao = query(collection(db, 'medicoes'), where('dispositivo_id', '==', estacao));
    const querySnapshot = await getDocs(medicoesEstacao);

    if (querySnapshot.empty) {
        throw new Error("Nenhuma medição encontrada.");
    }

    const allMeasurements = [];

    querySnapshot.forEach((doc) => {
        const data = doc.data();
        allMeasurements.push({
            dthr: new Date(data.dthr),
            sensor_id: data.sensor_id,
            valor: data.valor
        });
    });

    // Ordena as medições por data e hora
    allMeasurements.sort((a, b) => a.dthr - b.dthr);

    const sensorData = {};
    const timeData = [];

    allMeasurements.forEach(measurement => {
        const { dthr, sensor_id, valor } = measurement;

        // Verifica se a data já existe no timeData
        if (!timeData.includes(dthr)) {
            timeData.push(dthr);
        }

        // Inicializa o array para o sensor caso não exista
        if (!sensorData[sensor_id]) {
            sensorData[sensor_id] = new Array(timeData.length).fill(null);
        }

        // Atribui o valor à posição correspondente da data
        const index = timeData.indexOf(dthr);
        if (index !== -1) {
            sensorData[sensor_id][index] = valor;
        }
    });

    return { sensorData, timeData };
}